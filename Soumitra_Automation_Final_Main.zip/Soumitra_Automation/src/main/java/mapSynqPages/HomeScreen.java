package mapSynqPages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.lang.*;

import utility.myReusable;

public class HomeScreen extends myReusable{

	public By trafficAware  = By.id("also_traffic");
	public By fastest = By.id("also_fastest");
	public By tollAware = By.id("also_erp");
	public By shortest  = By.id("also_shortest");
	public By fromLoc  = By.id("poi_from");
	public By toLoc = By.id("poi_to");
	public By clearBtn   = By.id("btnClear");
	public By getDirectionBtn = By.id("get_direction");
	public By directionsTab = By.xpath("//a[@data-tabid='0']");
	public By ZoomIn = By.xpath("//img[@id='QiPanZoomBar_2_zoomin_innerImage']");
	public By ZoomOut = By.xpath("//img[@id='QiPanZoomBar_2_zoomout_innerImage']");
	

	public WebElement getDirectionTab()
	{
		return dr.findElement(directionsTab);
	}

	public WebElement getClearBtn()
	{
		return dr.findElement(clearBtn);
	}

	public WebElement getSourceLocation()
	{
		return dr.findElement(fromLoc);

	}

	public WebElement getDestinationLocation()
	{
		return dr.findElement(toLoc);
	}

	public WebElement getGetDirectionsBtn()
	{
		return dr.findElement(getDirectionBtn);
	}

	public WebElement getTrafficAwareCheckBox()
	{
		return dr.findElement(trafficAware);
	}

	public WebElement getFastestCheckBox()
	{
		return dr.findElement(fastest);
	}

	public WebElement getTollAwareCheckBox()
	{
		return dr.findElement(tollAware);
	}

	public WebElement getShortestCheckBox()
	{
		return dr.findElement(shortest);
	}

	public WebElement ZoomIn()
	{
		return dr.findElement(ZoomIn);
	}
	public WebElement ZoomOut()
	{
		return dr.findElement(ZoomOut);
	}
	
//Functions start here---
	
	//Zoom In/Out function--
	public void ZoomInOut()
	{
		ZoomIn().click();
		try{ Thread.sleep(5000); }
			catch(InterruptedException ie){	}
		ZoomOut().click();
	}
	
	//GetMap direction function--
	public boolean getDirections(String strSourceLoc, String strDestinationLoc) 
	{		
		getDirectionTab().click();		
		getClearBtn().click();			
		getSourceLocation().sendKeys(strSourceLoc);
		boolean sourceSelected = Boolean.valueOf(strSourceLoc);
		if(sourceSelected)
		{			
			getDestinationLocation().sendKeys(strDestinationLoc);
			boolean destinationSelected = Boolean.valueOf(strDestinationLoc);
			if(destinationSelected)
			{
				getGetDirectionsBtn().click();			
				try{ Thread.sleep(5000); }
				catch(InterruptedException ie){	}						

				return true;
			}
			else
			{
				System.out.println("The given Destination " + strDestinationLoc + " is not found.Please input correct value");
				return false;
			}
		}
		else
		{
			System.out.println("The given Source Location " + strSourceLoc + " is not found.Please input correct value");
			return false;
		}
	}

	  //Set Location function
	public void setLocation(String strSourceLoc, String strDestinationLoc)
	{
		getDirectionTab().click();
		getClearBtn().click();
		getSourceLocation().sendKeys(strSourceLoc);		
		getDestinationLocation().sendKeys(strDestinationLoc);
	
	}

	// Get all Checkbox and Unselect 
	public void uncheckAllCheckBoxes()
	{
		getDirectionTab().click();
		List<WebElement> checkBoxes = dr.findElements(By.xpath("//input[starts-with(@onclick,'toggle_route_checkbox')]"));

		for (int i = 0; i < checkBoxes.size(); i++) 
		{ 
			if(checkBoxes.get(i).isSelected())
			{
				checkBoxes.get(i).click(); 
			}
		} 

	}
	
	//Get all ChkBox and Select them all	
	public void checkAllCheckBoxes()
	{
		getDirectionTab().click();
		List<WebElement> checkBoxes = dr.findElements(By.xpath("//input[starts-with(@onclick,'toggle_route_checkbox')]"));

		for (int i = 0; i < checkBoxes.size(); i++) 
		{ 
			if(!checkBoxes.get(i).isSelected())
			{
				checkBoxes.get(i).click(); 
			}
		} 

	}
}
