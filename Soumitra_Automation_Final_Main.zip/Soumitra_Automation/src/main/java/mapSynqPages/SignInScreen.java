package mapSynqPages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utility.myReusable;

public class SignInScreen extends myReusable{

	public By userName = By.id("name");
	public By password =  By.id("password");
	public By signinBtn = By.className("button_org");
	public By forgotUserPwdLink = By.linkText("forgot_password");
	public By invalidusrpwdMsg = By.id("notice");						
	public By signInLink = By.linkText("Sign in");
	public By mapSynqHome = By.xpath("//a[@href='http://mapsynq.com']");
	public By Forgotpass = By.xpath("//a[@href='forgot_password']");
	public By ResetPaswd = By.xpath("//input[@value='Reset Password']");
	public By afterLogin = By.xpath("//h5[contains(text(),'Welcome !')]");
	
	public WebElement getUserNameField()
	{
		return dr.findElement(userName);
	}

	public WebElement getPasswordField()
	{
		return dr.findElement(password);
	}

	public WebElement getSigninBtn()
	{
		return dr.findElement(signinBtn);
	}

	public WebElement getForgotPwdUserLink()
	{
		return dr.findElement(forgotUserPwdLink);
	}

	public WebElement getInvalidUsrPwdMsg()
	{
		return dr.findElement(invalidusrpwdMsg);
	}

	public WebElement getsignInLink()
	{
		return dr.findElement(signInLink);
	}

	public WebElement getmapSynqHomeLink()
	{
		return dr.findElement(mapSynqHome);
	}

	public WebElement ForgotPasswd()
	{
		return dr.findElement(Forgotpass);
	}
	public WebElement ResetPaswd()
	{
		return dr.findElement(ResetPaswd);
	}
	public WebElement afterLogin()
	{
		return dr.findElement(afterLogin);
	}

}
