package utility;



import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

 //import io.appium.java_client.android.AndroidDriver;

public class myReusable {

	public static WebDriver dr = null;
	public WebDriver getDriver()
	{
		String os = System.getProperty("os.name").toLowerCase();
		
		if (os.contains("mac")) {
			String browserName = System.getProperty("browser");		
			browserName = browserName.toUpperCase();
			switch(browserName) 
			{
			case "CHROME" :
				dr = new ChromeDriver();
				break;
			case "FIREFOX" :
				String vpath = new File("src/driverfile/geckodriver").getAbsolutePath();		
				System.setProperty("webdriver.gecko.driver", vpath);
				dr = new FirefoxDriver();
				break;	
			case "IE" : 
				String IEdriverpath = new File("src/driverfile/IEDriverServer").getAbsolutePath();		
				System.setProperty("webdriver.ie.driver", IEdriverpath);
				dr = new InternetExplorerDriver();
				break;
			}
			return dr;
		}
		
		else if (os.contains("win")) {
			String browserName = System.getProperty("browser");		
			browserName = browserName.toUpperCase();
			switch(browserName) 
			{
			case "CHROME" :
				dr = new ChromeDriver();
				break;
			case "FIREFOX" :
				String Fpath = new File("src/driverfile/geckodriver").getAbsolutePath();		
				System.setProperty("webdriver.gecko.driver", Fpath);
				dr = new FirefoxDriver();
				break;	
			case "IE" : 
				String IEdriverpath = new File("src/driverfile/IEDriverServer").getAbsolutePath();		
				System.setProperty("webdriver.ie.driver", IEdriverpath);
				dr = new InternetExplorerDriver();
				break;
			}
			return dr;
		}
		
		else if (os.contains("android")) 
			{
			DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
			desiredCapabilities.setCapability("platformName", "Android");
			String apkpath = "path\\sampleapp.apk";
		    File app = new File (apkpath);
		    DesiredCapabilities capabilities= new DesiredCapabilities();
		    capabilities.setCapability(CapabilityType.BROWSER_NAME,"");
		    capabilities.setCapability("deviceName","Mobile");
		    capabilities.setCapability("platformName","Android");
		    capabilities.setCapability("app",app.getAbsolutePath());
		    capabilities.setCapability("appPackage", "com.test");
				    						
			try {
				// dr = new AppiumDriver(new URL("http://url.com"),capabilities);

			} catch (Exception e) {	}
		}
		
		return dr;
		
	}
	
}
