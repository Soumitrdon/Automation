package mapSynqTest;

import org.testng.annotations.Test;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import mapSynqPages.HomeScreen;
import utility.Screenshot;
import utility.myReusable;
import utility.parseJsonClass;


public class TC01_MapSearchFunction extends myReusable{

	parseJsonClass pjc= new parseJsonClass();
	String browserUrl="";
	HomeScreen dc = new HomeScreen();
	JSONObject jsonObj= null;

	
	@BeforeTest
	public void beforeTest()
	{
		dr.manage().window().maximize();
		browserUrl = System.getProperty("url");
		jsonObj= pjc.getJsonTestDataObject();
		System.out.println("Before test");
		String url = "http://www.mapsynq.com/";
		dr.get(url);
	}

	@BeforeMethod
	public void beforeMethos() 
	{
		dr.navigate().refresh();
	}
	
	@Test(priority = 0)
	public void ValidateMapDirection()
	{   
		try
		{
			String SourceLoc=pjc.parseJsonTestData(jsonObj, "MapData", "Source");
			String DestLoc= pjc.parseJsonTestData(jsonObj, "MapData", "Destination");
			if(dc.getDirections(SourceLoc, DestLoc))
			{
				System.out.println("The direction between" + SourceLoc + " and " + DestLoc +" Is Displayed");
			}
			else
			{
				System.out.println("The direction between" + SourceLoc + " and " + DestLoc +" Is Displayed");
				System.exit(1);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Screenshot.captureScreenshot("error");
		}

	}
	@Test(priority = 1)
	public void  ValidateAndClickOnAlertForAllCheckboxesUnchecked()
	{
		try
		{	
			String SourceLoc=pjc.parseJsonTestData(jsonObj, "testMapDirectionWithAllOptionsDisabled", "Source");
			String DestLoc= pjc.parseJsonTestData(jsonObj, "testMapDirectionWithAllOptionsDisabled", "Destination");
			dc.setLocation(SourceLoc, DestLoc);
			dc.uncheckAllCheckBoxes();
			dc.getGetDirectionsBtn().click();				
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Screenshot.captureScreenshot("error");
		}
	}

	@Test(priority = 2)
	public void  ValidateDirectionDisplayedForAllCheckboxesChecked()
	{
		try
		{
			String SourceLoc=pjc.parseJsonTestData(jsonObj, "testMapDirectionWithAllOptionsEnabled", "Source");
			String DestLoc= pjc.parseJsonTestData(jsonObj, "testMapDirectionWithAllOptionsEnabled", "Destination");

			dc.setLocation(SourceLoc, DestLoc);
			dc.checkAllCheckBoxes();
			dc.getGetDirectionsBtn().click();
			System.out.println("The direction is displayed for all the checkboxes checked");
		
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Screenshot.captureScreenshot("error");
		}
	}
	
	@Test(priority = 3)
	public void  ZoomFunction()
	{
		try
		{
			System.out.println("Checking Zoom Functionality");
			dc.ZoomInOut();
		
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Screenshot.captureScreenshot("error");
		}
	}
	
	@AfterSuite
	public void afterSuite()
	{
		dr.close();
	}
}
