package mapSynqTest;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import mapSynqPages.SignInScreen;
import utility.Screenshot;
import utility.myReusable;
import utility.parseJsonClass;

public class TC02_SignInFunction extends myReusable {

	String browserUrl="";
	SignInScreen signIn = new SignInScreen();
	WebDriver dr = getDriver();
	JSONObject jsonObj= null;
	parseJsonClass pjc= new parseJsonClass();

	@BeforeTest
	public void beforeTest()
	{
		dr.manage().window().maximize();
		browserUrl = System.getProperty("url");
		jsonObj= pjc.getJsonTestDataObject();
		System.out.println("Before test");
		String url = "http://www.mapsynq.com/";
		dr.get(url);
	}

	
	@Test
	public void SignIn()
	{   
		try
		{
			String userName = pjc.parseJsonTestData(jsonObj, "testLogin", "username");
			String password = pjc.parseJsonTestData(jsonObj, "testLogin", "password");
			
			signIn.getmapSynqHomeLink().click();
					
			signIn.getsignInLink().click();
			signIn.getUserNameField().sendKeys(userName);
			signIn.getPasswordField().sendKeys(password);
			signIn.getSigninBtn().click();
			
			String loginuser = "Welcome !";
			String frompageUsername = signIn.afterLogin().getText();
			if (frompageUsername != loginuser){
				System.out.println("Successful Login");
			}
			else {
				System.out.println("Unsuccessful Login");
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Screenshot.captureScreenshot("error");
		}

	}
	
	@AfterSuite
	public void afterSuite()
	{
		dr.close();
	}
}
