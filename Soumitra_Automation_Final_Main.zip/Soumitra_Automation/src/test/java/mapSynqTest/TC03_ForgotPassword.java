package mapSynqTest;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import mapSynqPages.SignInScreen;
import utility.Screenshot;
import utility.myReusable;
import utility.parseJsonClass;

public class TC03_ForgotPassword extends myReusable {

	String browserUrl="";
	SignInScreen signIn = new SignInScreen();
	WebDriver dr = getDriver();
	JSONObject jsonObj= null;
	parseJsonClass pjc= new parseJsonClass();

	@BeforeTest
	public void beforeTest()
	{
		dr.manage().window().maximize();
		browserUrl = System.getProperty("url");
		jsonObj= pjc.getJsonTestDataObject();
		System.out.println("Before test");
		String url = "http://www.mapsynq.com/";
		dr.get(url);
	}
	
	@Test
	public void ForgotPassword()
	{   
		try
		{
			signIn.getmapSynqHomeLink().click();
			WebDriverWait wait = new WebDriverWait(dr,60);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='forgot_password']")));
			String Mailid = pjc.parseJsonTestData(jsonObj, "testValidLogin", "username");
			
			signIn.ForgotPasswd().click();
			signIn.ForgotPasswd().sendKeys(Mailid);
			signIn.ResetPaswd().click();
			
		}
	
	catch (Exception e)
	{
		e.printStackTrace();
		Screenshot.captureScreenshot("error");
	}

}

@AfterSuite
public void afterSuite()
{
	dr.close();
}
}
